<?php
session_start();
?>
<form action="top.php" method = 'post'>

        <input type="text" name = 'otp' placeholder="Confirm OTP">
        <input type="submit" value="Confirm OTP" name =  "top" class="btn">
		<br><br>

    </form>
	
<?php
if(isset($_POST['top'])){
	$otp = $_POST['otp'];
	$rand = $_SESSION['rand'];
	
	if ($rand == $otp){
		echo "Success";
		//header('location:index.php');
	}
	else{
		echo "Wrong";
	}
		
	//header('location:otp.php');
}
?>