<?php
session_start();
?>
<form action="sentotp.php" method = 'post'>

        <input type="email" name = 'email' placeholder="email">
            <input type="password" name = 'password' placeholder="Password">
       
		<input type="submit" value="Login" name =  "signin" class="btn">
		<br><br>

    </form>
	
<?php
if(isset($_POST['signin'])){
	$email = $_POST['email'];
	$rand = rand(100000,999999);
	$_SESSION['rand'] = $rand;
	
	$subject = 'OTP From Kidz';
	$message = $rand;
		
	$to = $email;
	$mail_subject = 'From ICT Crue';
	$email_body = "This is OTP: " . $rand;
	$sendemail = 'kidz.kidz.kidz.kidza.kidz@gmail.com';
	$header = "From: {$sendemail}\r\nContent-Type: text/html";
	
	mail($to, $mail_subject, $email_body, $header);
		
	header('location:top.php');
}
?>